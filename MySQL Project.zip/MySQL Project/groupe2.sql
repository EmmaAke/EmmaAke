-- MySQL dump 10.13  Distrib 8.0.24, for Win64 (x86_64)
--
-- Host: localhost    Database: projet
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administration`
--

DROP TABLE IF EXISTS `administration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administration` (
  `adminID` varchar(10) NOT NULL,
  `nom` varchar(10) NOT NULL,
  `prenoms` varchar(20) NOT NULL,
  `poste` varchar(10) NOT NULL,
  PRIMARY KEY (`adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administration`
--

LOCK TABLES `administration` WRITE;
/*!40000 ALTER TABLE `administration` DISABLE KEYS */;
/*!40000 ALTER TABLE `administration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chambre`
--

DROP TABLE IF EXISTS `chambre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chambre` (
  `N_chambre` int NOT NULL,
  `numTel` int NOT NULL,
  `prixChambre` int NOT NULL,
  `clientID` varchar(10) NOT NULL,
  PRIMARY KEY (`N_chambre`),
  KEY `fk_clientID3` (`clientID`),
  CONSTRAINT `fk_clientID3` FOREIGN KEY (`clientID`) REFERENCES `clienthotel` (`clientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chambre`
--

LOCK TABLES `chambre` WRITE;
/*!40000 ALTER TABLE `chambre` DISABLE KEYS */;
/*!40000 ALTER TABLE `chambre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clienthotel`
--

DROP TABLE IF EXISTS `clienthotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clienthotel` (
  `clientId` varchar(10) NOT NULL,
  `nom` varchar(10) NOT NULL,
  `prenoms` varchar(20) NOT NULL,
  `adresse` varchar(20) NOT NULL,
  `telephone` varchar(20) NOT NULL,
  PRIMARY KEY (`clientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clienthotel`
--

LOCK TABLES `clienthotel` WRITE;
/*!40000 ALTER TABLE `clienthotel` DISABLE KEYS */;
/*!40000 ALTER TABLE `clienthotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `commande`
--

DROP TABLE IF EXISTS `commande`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `commande` (
  `commandeID` varchar(10) NOT NULL,
  `clientID` varchar(10) NOT NULL,
  `platID` varchar(10) NOT NULL,
  PRIMARY KEY (`commandeID`),
  KEY `fk_clientID5` (`clientID`),
  KEY `fk_plat` (`platID`),
  CONSTRAINT `fk_clientID5` FOREIGN KEY (`clientID`) REFERENCES `clienthotel` (`clientId`),
  CONSTRAINT `fk_plat` FOREIGN KEY (`platID`) REFERENCES `restaurant` (`platID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `commande`
--

LOCK TABLES `commande` WRITE;
/*!40000 ALTER TABLE `commande` DISABLE KEYS */;
/*!40000 ALTER TABLE `commande` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employe`
--

DROP TABLE IF EXISTS `employe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employe` (
  `employeID` varchar(10) NOT NULL,
  `nomEmploye` varchar(10) NOT NULL,
  `prenoms` varchar(20) NOT NULL,
  `posteEmploye` varchar(10) NOT NULL,
  `adminID` varchar(10) NOT NULL,
  PRIMARY KEY (`employeID`),
  KEY `fk_adminId` (`adminID`),
  CONSTRAINT `fk_adminId` FOREIGN KEY (`adminID`) REFERENCES `administration` (`adminID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employe`
--

LOCK TABLES `employe` WRITE;
/*!40000 ALTER TABLE `employe` DISABLE KEYS */;
/*!40000 ALTER TABLE `employe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reservation`
--

DROP TABLE IF EXISTS `reservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reservation` (
  `reservationID` int NOT NULL,
  `dateReservation` date NOT NULL,
  `dateArrivee` date NOT NULL,
  `clientID` varchar(10) NOT NULL,
  `N_chambre` int NOT NULL,
  PRIMARY KEY (`reservationID`),
  KEY `fk_chambre` (`N_chambre`),
  KEY `fk_clientID4` (`clientID`),
  CONSTRAINT `fk_chambre` FOREIGN KEY (`N_chambre`) REFERENCES `chambre` (`N_chambre`),
  CONSTRAINT `fk_clientID4` FOREIGN KEY (`clientID`) REFERENCES `clienthotel` (`clientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reservation`
--

LOCK TABLES `reservation` WRITE;
/*!40000 ALTER TABLE `reservation` DISABLE KEYS */;
/*!40000 ALTER TABLE `reservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restaurant`
--

DROP TABLE IF EXISTS `restaurant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restaurant` (
  `platID` varchar(10) NOT NULL,
  `nomPlat` varchar(20) NOT NULL,
  `prix` int NOT NULL,
  PRIMARY KEY (`platID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restaurant`
--

LOCK TABLES `restaurant` WRITE;
/*!40000 ALTER TABLE `restaurant` DISABLE KEYS */;
/*!40000 ALTER TABLE `restaurant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `s_occupe`
--

DROP TABLE IF EXISTS `s_occupe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `s_occupe` (
  `occupationID` varchar(10) NOT NULL,
  `clientID` varchar(10) NOT NULL,
  `employeID` varchar(10) NOT NULL,
  PRIMARY KEY (`occupationID`),
  KEY `fk_employeID` (`employeID`),
  KEY `fk_clientID` (`clientID`),
  CONSTRAINT `fk_clientID` FOREIGN KEY (`clientID`) REFERENCES `clienthotel` (`clientId`),
  CONSTRAINT `fk_employeID` FOREIGN KEY (`employeID`) REFERENCES `employe` (`employeID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `s_occupe`
--

LOCK TABLES `s_occupe` WRITE;
/*!40000 ALTER TABLE `s_occupe` DISABLE KEYS */;
/*!40000 ALTER TABLE `s_occupe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voiture`
--

DROP TABLE IF EXISTS `voiture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voiture` (
  `placeID` varchar(10) NOT NULL,
  `marqueVoiture` varchar(20) NOT NULL,
  `clientID` varchar(10) NOT NULL,
  PRIMARY KEY (`placeID`),
  KEY `fk_clientID2` (`clientID`),
  CONSTRAINT `fk_clientID2` FOREIGN KEY (`clientID`) REFERENCES `clienthotel` (`clientId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voiture`
--

LOCK TABLES `voiture` WRITE;
/*!40000 ALTER TABLE `voiture` DISABLE KEYS */;
/*!40000 ALTER TABLE `voiture` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-02  1:47:53
