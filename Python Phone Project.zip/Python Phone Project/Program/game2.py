print("\nWelcome to Trivia Quiz")
score=0
q=input("Would you like to start[y/n]?: ")
while q=="y":
    q1=input("What is the capital of Mongolia?: ")
    if q1=="oulan-bator":
        print("Correct")
        score+=1
    else:
        print("Wrong")

    q2=int(input("Give the root square of 4: "))
    if q2==2:
        print("Correct")
        score+=1
    else:
        print("Wrong")

    q3=input("What is the most secure OS : ")
    if q3=="linux":
        print("Correct")
        score+=1
    else:
        print("Wrong")

    q4=int(input("[(x+2*5)(0-1+1)]= "))
    if q4==0:
        print("Correct")
        score+=1
    else:
        print("Wrong")

    q5=input("Is this game interesting[y/n]?: ")
    if q5=="y":
        print("Correct")
        score+=1
        
    elif q5=="n":
        print("Maybe")
        score+=0.5
        
    else:
        print("Wrong")
        
    print("GAME OVER!!! Your final score is ",score,"/5")
    percentage=(score/5)*100
    print("Success percentage ",percentage,"%")
    break

print("Good Bye")


    
