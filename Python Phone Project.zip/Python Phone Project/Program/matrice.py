print("PROGRAMME DE MATRICE")
dim=int(input("Entrer la dimension de la matrice: "))
matrix=[]
ctrl=True
for i in range (0,dim):
    data=[]
    for j in range (0,dim):
        print("\nligne",i+1,"colonne",j+1)
        data.append(float(input("Saisir le nombre: ")))
    matrix.append(data)
while True:
    print("\nMENU\n"
        "1. Afficher la matrice \n"
          "2. Vérifier si la matrice est symétrique ;\n"
          "3. Vérifier si la matrice est une matrice unité ou matrice identité ;\n"
          "4. Vérifier si la matrice est diagonale ;\n"
          "5. Vérifier si la matrice est triangulaire supérieure ;\n"
          "6. Vérifier si la matrice est triangulaire inférieure ;\n"
          "7. Multiplier la matrice par un réel qu’il aura à saisir;\n"
          "8. Calculer le déterminant de la matrice ;\n"
          "9. Calculer la matrice transposée de la matrice saisie\n")
    choix=int(input("\nEntrer le chiffre correspondant au choix: "))
    if choix==1:
        print("La matrice saisie est: ")
        print(*matrix,sep="\n")
    elif choix==2:
        def symetric(matrix,dim):
            for i in range(0,dim):
                for j in range(0,dim):
                    if matrix[i][j]!=matrix[j][i]:
                        return False
            return True
        if (symetric(matrix, dim)):
            print("La matrice est symetrique")
        else:
            print("La matrice n`est pas symetrique")
    elif choix==3:
        for i in range(0,dim):
            for i in range(0,dim):
                if i==j and matrix[i][j]!=1:
                    ctrl=False;
                    break
                elif i!=j and matrix[i][j]!=0:
                    ctrl=False
                    break
        if ctrl==True:
            print("Cette matrice est une matrice identite ")
        else:
            print("Cette matrice n`est pas une matrice identite ")
    elif choix==4:
        def diag(matrix,dim):
            for i in range(0,dim):
                for j in range(0,dim):
                    if  i!=j and matrix[i][j]!=0:
                        return False
            return True
        if diag(matrix,dim):
            print("La matrice est diagonale")
        else:
            print("La matrice n`est pas diagonale")
    elif choix==5:
        def triangsup(matrix):
            for i in range(1,len(matrix)):
                for j in range(0,i):
                    if matrix[i][j]!=0:
                        return False
            return True
        if triangsup(matrix):
            print("La matrice est triangulaire superieure")
        else:
            print("La matrice n`est pas  triangulaire superieure")
    elif choix==6:
        def trianginf(matrix):
            for i in range(0,len(matrix)):
                for j in range(i+1,len(matrix)):
                    if matrix[i][j]!=0:
                        return False
            return True
        if trianginf(matrix):
            print("La matrice est triangulaire inferieure")
        else:
            print("la matrice n`est pas  triangulaire inferieure")
    elif choix==7:
        R=int(input("\nSaisir un reel pour multiplier la matrice: "))
        for i in range(0,dim):
            for j in range (0,dim):
                matrix[i][j]=R*matrix[i][j]
        print("La multiplication donne: ")
        print(*matrix,sep="\n")
    elif choix==8:
        det=0
    elif choix==9:
        for row in matrix : 
            print(row) 
        rez = [[matrix[j][i] for j in range(len(matrix))] for i in range(len(matrix[0]))] 
        print("\n")
        print("La matrice transposee est")
        for row in rez: 
            print(row)
    else :
        False
        break
    
