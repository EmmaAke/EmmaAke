import os
import datetime
import menu

x = datetime.datetime.now()

while True:
    print("--------------------------------------------------------------------------------------------------")
    print("\n\n")
    print(x.strftime("%c"))
    print("\n")

    print("MyPhone")

    print(menu.menuP())
    print("")
    print("--------------------------------------------------------------------------------------------------\n")
    ch=input("\nMake your choice: ")

    if ch=="b":
        print(menu.menuB())
        ch2=int(input())
        if ch2==1:
            notes=str(input("Write a note: "))
            g=open("Notes.txt","w")
            g.write(notes)
            g.close
        elif ch2==2:
            g=open("Notes.txt","r")
            print(g.read())
            g.close
        elif ch2==3:
            g=open("Notes.txt","w")
            g.write("")
            g.close
        elif ch2==4:
            True
            
    elif ch=="c":
        names=[]
        numbers=[]
        dico_contacts={}
        print(menu.menuC())
        ch2=int(input())
        if ch2==1:
            f=open("Contacts.txt","r")
            print(f.read())
            f.close
        elif ch2==2:
            names.append(input("Name: "))
            numbers.append(int(input("Number: ")))
            for i,j in zip(names,numbers):
                dico={i:j}
                dico_contacts.update(dico)
                with open("Contacts.txt","a") as f:
                    for i in dico_contacts:
                        f.write(str(dico_contacts)+"\n")
                    
                f.close
            
        elif ch2==4:
            True
    elif ch=="cc":
        print(menu.menuCc())
        ch2=int(input("Calculator choice: "))
        if ch2==1:
            import calculatrice
        if ch2==2:
            import matrice
        if ch2==3:
            True
    elif ch=="g":
        print(menu.menuG())
        ch2=int(input("Game choice: "))
        if ch2==1:
            import game1
        elif ch2==2:
            import game2
        elif ch2==3:
            True
    elif ch=="p":
        print(menu.menuS())
        ch2=input()
        if ch2=="y":
            print("Shutting Down...")
            os.system("pause")
            False
            break
            
        else:
            True
            

    else:
        True
