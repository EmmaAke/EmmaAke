import mod
Q=1
while Q==1:
    print("MIINI-CALCULATRICE")
    print("1-Addition")
    print("2-Soustraction")
    print("3-Multiplication")
    print("4-division")
    choix=int(input("Choisissez votre operation(Entrer juste le chiffre): "))
    n1=float(input("Entrer un nombre: "))
    n2=float(input("Entrer un autre nombre: "))

    if choix==1:
        print (mod.add(n1,n2))
    elif choix==2:
        print(mod.sus(n1,n2))
    elif choix==3:
        print(mod.mult(n1,n2))
    elif choix==4:
        print(mod.div(n1,n2))
    Q=int(input("Voulez vous refaire un calcul [1 pour oui,2 pour non]: "))
    continue



