import random

nat=random.randint(0,100)

Q=1
while Q==1:
    ns=int(input("Saisissez un nombre compris entre 1 et 100: "))
    if ns<nat:
        print("Plus grand")
    elif ns>nat:
        print("Plus petit")
    elif ns==nat:
        print("Congrats!! ")
        break
    Q=int(input("Voulez vous reessayer [1-oui/2-non]: "))
    continue

if Q==2:
    print("Le nombre etait ",nat)
    
