def menuP():
    print("\nb-Bloc-notes \tc-Contacts\n")
    print("\tcc-Calculator \t g-Games")
    return "\np-Power Off\n"
def menuB():
    return "1-Create a new note \t 2-Show note \t 3-Delete a note \t 4-Back"
def menuC():
    return "1-Show Contacts \t 2-Add a contact  \t 3-Back"
def menuCc():
    return "1-Simple Calculator \t 2-Matrix Caluclator \t 3-Back"
def menuG():
    return "1-Guessing number 2-Trivia Quiz 3-Back"
def menuS():
    return "Confirm Shut Down?[y/n]: "
