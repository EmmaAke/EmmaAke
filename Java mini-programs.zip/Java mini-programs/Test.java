import java.util.ArrayList;
import java.util.List;

public class Test {
    public static void main(String[] args) {
        List<Vehicule> engins=new ArrayList<>();

        Vehicule toyota=new Voiture("6537AI", 2007, 1250);
        Vehicule jeep =new Voiture("9159BG", 2018, 15000);
        Vehicule af1=new Avion("A320", 2015, 100000);
        Vehicule af2=new Avion("A330", 2016, 110000);
        Vehicule af3=new Avion("A380", 2017, 125000);

        engins.add(toyota);
        engins.add(jeep);
        engins.add(af1);
        engins.add(af2);
        engins.add(af3);

        for (Vehicule v : engins) {
                System.out.println(v); 
        }
      
    }
}
