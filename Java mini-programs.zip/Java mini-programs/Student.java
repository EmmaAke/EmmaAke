public class Student  {
    private String nom;
    private int note;
    
    public Student(String nom,int note) throws NegativeNoteException{
        if(note<0)
            throw new NegativeNoteException();

        else{
            this.nom=nom;
            this.note=note;
        }
    }
}
