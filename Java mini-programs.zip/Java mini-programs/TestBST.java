public class TestBST {
    static void balancedBST(PersoInscrit[] arr,int n,PersoInscrit[] narr){
        for (int i = 0; i < n; i++) {
            int a=i;
            if(arr[a].app!=null){
                //System.out.println("a invite "+arr[i].app[1].fname);
                narr[a]=arr[i];
                narr[a+1]=arr[i].app[0];
                narr[a+2]=arr[i].app[1];
                a=a+3;
            }
            else{
                //System.out.println("n`a pas invite");
                continue;
            }
        }
    }

    static void maxAmt(PersoInscrit[] arr,int n){
        int max=arr[0].mont;
        for (int i = 0; i < arr.length; i++) {
            if (max<arr[i].mont) {
                max=arr[i].mont;
                System.out.println(arr[i]);
            }
        }
    }

    static void minAmt(PersoInscrit[] arr,int n){
        int min=arr[0].mont;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr.length; j++) {
                if (min>arr[j].mont) {
                    min=arr[j].mont;
                    System.out.println(arr[j]);
                }
            }
            
        }
    }

    static void showTab(PersoInscrit[] arr,int n){
        System.out.println("Tableau");
        for (int i = 0; i < n; i++) {
            System.out.print(arr[i].mont+" ");
        }
    }
    public static void main(String[] args) {        
        PersoInscrit p7=new PersoInscrit("yawa", "ok", 650);
        PersoInscrit p5=new PersoInscrit("koffi", "jiji", 5000);
        PersoInscrit p6=new PersoInscrit("adjo", "elsa", 3800);
        PersoInscrit p3=new PersoInscrit("komi", "alvin", 50);
        PersoInscrit p4=new PersoInscrit("komla", "bill", 11000);
        PersoInscrit p2=new PersoInscrit("kokou", "ahmed", 1500);
        PersoInscrit p1=new PersoInscrit("kossi", "agbe", 2000);

        PersoInscrit[] p1arr={p2,p3};
        PersoInscrit[] p2arr={p4,p5};
        PersoInscrit[] p3arr={p6,p7};

        p1.setApp(p1arr);
        p2.setApp(p2arr);
        p3.setApp(p3arr);

        PersoInscrit array[]={p1,p4,p3,p5,p2,p6,p7};
        int lg=array.length;
        PersoInscrit newArray[]=new PersoInscrit[lg];

        System.out.println("Avant tri");
        showTab(array,lg);
        System.out.println();

        balancedBST(array, lg, newArray);

        System.out.println("Apres tri");
        showTab(newArray,lg);
        System.out.println();

        System.out.println("Info perso montant max");
        maxAmt(array, lg);
        
        System.out.println("Info perso montant min");
        minAmt(array, lg);



    }
}
