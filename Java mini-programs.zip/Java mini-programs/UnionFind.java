public class UnionFind {
    
    public static void initialize(int Arr[],int n){
        for (int i=0;i<n;i++){
            Arr[i]=i;
        }
    }

    public static boolean find(int arr[],int a,int b){
        if (arr[a]==-arr[b])
            return true;
        else
            return false;
    }

    public static void union(int arr[],int n,int a, int b){
        int temp=arr[a];
        for (int i =0;i<n;i++){
            if(arr[i]==temp){
                arr[i]=-arr[b];
            }
        }
    }

    public static void showTab(int arr[],int N){
        System.out.println("Array: ");
        for (int i=0;i<N;i++)
            System.out.print(arr[i]+" ");
        System.out.println();
    }

    public static void main(String[] args) {
        int tab[]={0,1,2,3,4,5,6,7,8,9};
        int n=tab.length;

        initialize(tab, n);
        showTab(tab, n);
        System.out.println("Find entre 0 et 7: "+find(tab, 0, 7));

        System.out.println("Find entre 5 et 6: "+find(tab, 5, 6));

        System.out.println("Find avant union entre 4 et 3: "+find(tab, 4, 3));

        System.out.println("");
        
        union(tab, n, 2, 1);
        union(tab, n, 4, 3);
        union(tab, n, 8, 4);
        union(tab, n, 9, 2);
        System.out.println("");

        System.out.println("Find apres union entre 4 et 3: "+find(tab, 4, 3));

        System.out.println("Find apres union entre 9 et 2: "+find(tab, 9, 2));
        showTab(tab, n);

        
        
    }


}

