public class Projet {
    public static void main(String[] args) {
        try {
            Student k=new Student("popo",-12);    
        } catch (Exception e) {
            //TODO: handle exception
        }
        
    }
}
