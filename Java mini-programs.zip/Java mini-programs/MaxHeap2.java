public class MaxHeap2 {
    
    static void maxHeapify(int arr[],int i,int n){
        int left=2*i;
        int right=2*i+1,largest;
        if(left<=n && arr[left]>arr[i])
            largest=left;
        else
            largest=i;
        
        if(right<=n && arr[right]>arr[largest])
            largest=right;

        if(largest!=i){
            posSwap(arr, i, largest);
            maxHeapify(arr, largest, n);
        }
    }


    static void posSwap(int arr[],int i,int j){
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }
    
    
    static void showTab(int arr[]){
        int max=arr.length;
        for (int i=0;i<max;i++)
            System.out.print(arr[i]+" ");
        System.out.println();
    }

    public static void main(String[] args) {
        int arr[] = {10, 20, 15, 17, 9, 21};
        int n = arr.length;

        System.out.print("Given array: ");
        showTab(arr);

        maxHeapify(arr, 0, n-1);

        System.out.print("Sorted array: ");
        showTab(arr);
    }
}
