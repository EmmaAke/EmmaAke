public class Avion extends Voiture{

    protected double vitesse;

    public Avion(String matricule,int year,double prix){
        super(matricule, year, prix);
        this.vitesse=0;
    }

    public void demarrer(){
        System.out.println("Avion en cours de demarrage: "+super.getMle());

    }

    public void accelerer(double nvt){
        this.vitesse=nvt;
        
        System.out.println("Nouvelle Vitesse: "+nvt);
    }
}
