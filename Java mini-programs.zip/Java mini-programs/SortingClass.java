public class SortingClass {
    
    static void posSwap(int arr[],int i,int j){
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void sortingIO(int arr[],int n){
        for(int i=0;i<n;i++){
           for(int j=i+1;j<n;j++){ 
                if(arr[i]<arr[j])
                    posSwap(arr, i, j);
            }
        }
    }

    static void sortingOI(int arr[],int n){
        for(int i=0;i<n;i++){
           for(int j=i+1;j<n;j++){ 
                if(arr[i]>arr[j])
                    posSwap(arr, i, j);
            }
        }
    }
    
    static void showTab(int arr[]){
        int max=arr.length;
        for (int i=0;i<max;i++)
            System.out.print(arr[i]+" ");
        System.out.println();
    }
    
    
    
    public static void main(String[] args) {
        int num[]={20,9,13,1,0,150};

        System.out.print("Initial array: ");
        showTab(num);

        int x=num.length;
        sortingIO(num, x);

        System.out.print("Sorted array: ");
        showTab(num);

        sortingOI(num, x);

        System.out.print("Sorted array in the other way: ");
        showTab(num);

    }
}
