public class MinHeap2 {
    
    static int parent(int i) {
        return i / 2; 
        }
 
    static int leftChild(int i) { 
        return (2 * i);
     }
 
    static int rightChild(int i){
        return (2 * i) + 1;
    }

    static boolean isLeaf(int i,int arr[])
    {
        int n=arr.length+1;
        if (i > (n / 2) && i <= n) {
            return true;
        }
 
        return false;
    }


    static void minHeapify(int arr[],int i){
        if (!isLeaf(i, arr)){
            if(arr[i]>arr[leftChild(i)] || arr[i]<arr[rightChild(i)]){
                if(arr[leftChild(i)] < arr[rightChild(i)]){
                    posSwap(arr, i, leftChild(i));
                    minHeapify(arr, leftChild(i));
                }
                else{
                    posSwap(arr, i, rightChild(i));
                    minHeapify(arr, rightChild(i));
                }
            }
        }
    }
    

    static void posSwap(int arr[],int i,int j){
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void showTab(int arr[]){
        int max=arr.length;
        for (int i=0;i<max;i++)
            System.out.print(arr[i]+" ");
        System.out.println();
    }

    public static void main(String[] args) {
        int arr[] = {10, 20, 15, 17, 9, 21};

        System.out.print("Given array: ");
        showTab(arr);

        minHeapify(arr, 1);

        System.out.print("Sorted array: ");
        showTab(arr);
    }
}
