class NegativeNoteException extends Exception{
    public NegativeNoteException(){
        System.out.println("Note negative");
    }
}