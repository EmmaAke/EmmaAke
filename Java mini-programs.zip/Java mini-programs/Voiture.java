public class Voiture extends Vehicule {
    protected double vitesse;
    public Voiture(String matricule,int year,double prix){
        super(matricule, year, prix);
        this.vitesse=0;
    }

    public void demarrer(){
        System.out.println("Voiture en cours de demarrage: "+super.getMle());
    }

    public void accelerer(double nvt){
        this.vitesse=nvt;
        System.out.println("Nouvelle Vitesse: "+nvt);
    }
}
