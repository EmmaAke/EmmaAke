public class PersoInscrit {
    String fname,lname;
    int mont;
    PersoInscrit[] app;

    public PersoInscrit(String lname, String fname, int mont){
        this.lname=lname;
        this.fname=fname;
        this.mont=mont;
    }

    public void setApp(PersoInscrit[] app){
        this.app=app;

    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Nom: "+lname+" Prenom: "+fname+" Montant: "+mont+" ";
    }
}
