abstract class Vehicule {
    private String matricule;
    private int year;
    private double prix,vitesse;

    public Vehicule(String matricule,int year,double prix){
        this.matricule=matricule;
        this.prix=prix;
        this.year=year;
        this.vitesse=0;
    }

    public String getMle(){
        return this.matricule;
    }

    public int getYear(){
        return this.year;
    }

    public double getPrice(){
        return this.prix;
    }


    public abstract void demarrer();

    public abstract void accelerer(double nvt);


    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "\nMatricule: "+this.matricule+" Annee:"+this.year+" Prix: "+this.prix+" Vitesse:"+this.vitesse;
    }

    
}
