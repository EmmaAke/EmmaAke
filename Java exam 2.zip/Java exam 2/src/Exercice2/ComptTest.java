package Exercice2;

public class ComptTest {
    public static void main(String[] args) {
        Compte c1=new Compte("Koffi", 2000);

        c1.retrait(5000);
        c1.retrait(1000);
    }
}
