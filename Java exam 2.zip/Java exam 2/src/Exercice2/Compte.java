package Exercice2;

class Compte {
    private double solde;
    private String name;

    public Compte(String name, double solde){
        this.name=name;
        this.solde=solde;
    }

    public void retrait(double montant){
        if (montant>solde) {
            System.out.println("Le montant du retrait a depasse le solde du compte\n");
        } else {
            this.solde-=montant;
            System.out.println("Retrait de "+montant+" effectue\n Nouveau solde de "+this.name+": "+this.solde+"\n");
        }
    }
}
