package Exercice3;

public class EmployeeTest {
    public static void main(String[] args) {
        Employe em1=new Employe();
        Employe em2=new Employe();

        em1.setNom("kodjo");
        em1.setPnom("blaise");
        try {
            em1.setSal(-12.0);
        } catch (Exception e) {
            //TODO: handle exception
        }

        try {
            em1.setSal((double) 50000);
        } catch (Exception e) {
            //TODO: handle exception
        }

        em2.setNom("koffi");
        em2.setPnom("jean");
        try {
            em2.setSal((double) 100000);
        } catch (Exception e) {
            //TODO: handle exception
        }

        System.out.println("Salaire annuel de "+em1.getNom()+" :"+em1.anSal()+"");
        System.out.println("Salaire annuel de "+em2.getNom()+" :"+em2.anSal()+"");

        em1.increaseSal(10);
        em2.increaseSal(10);


        System.out.println("\nApres augmentation:");
        System.out.println("Salaire annuel de "+em1.getNom()+" :"+em1.anSal()+"");
        System.out.println("Salaire annuel de "+em2.getNom()+" :"+em2.anSal()+"");

    }
}
