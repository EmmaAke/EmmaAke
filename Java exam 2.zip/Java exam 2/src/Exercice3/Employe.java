package Exercice3;

class Employe {
    protected String prenom,nom;
    protected double salaire;

    public Employe(){
        this.prenom="";
        this.nom="";
        this.salaire=0;
    }

    public void setPnom(String pnom){
        this.prenom=pnom;
    }

    public void setNom(String nom){
        this.nom=nom;
    }

    public void setSal(Double sal) throws ExceptionSalary{
        if (sal<0) {
            throw new ExceptionSalary();
        } else {
            this.salaire=sal;
        }
        
    }

    public String getPnom(){
        return prenom;
    }

    public String getNom(){
        return nom;
    }

    public double getSal(){
        return salaire;
    }

    public double anSal(){
        return salaire*12;
    }

    public void increaseSal(int aug){
        double tx=(salaire*aug)/100;
        this.salaire+=tx;
    }

}
