package Exercice3;

public class ExceptionSalary extends Exception {
    public ExceptionSalary(){
        System.out.println("Attention - Salaire negatif\n");
    }
}
