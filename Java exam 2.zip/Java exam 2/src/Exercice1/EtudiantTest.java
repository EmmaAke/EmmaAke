package Exercice1;

/**
 * EtudiantTest
 */

public class EtudiantTest {

    static void ArraytoTree(Etudiant[] arr,int nb){
        //int a=nb;
        for (int i = 0; i < nb; i++) {
            
            for (int j = 0; j < nb; j++) {
                int temp=arr[j].age;
                int a=j+1;
                if (a<nb) {
                    if (temp>arr[a].age) {
                        posSwap(arr, i, a);
                        
                    }
                }
            }
        }
    }
    

    static void posSwap(Etudiant[] arr,int i,int j){
        Etudiant temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    static void maxAge(Etudiant[] arr,int nb){
        int max=arr[0].age;
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < i; j++) {
                if (max<arr[j].age) {
                    max=arr[j].age;
                    
                    System.out.println("Le plus age est l`"+arr[i]);
                }
            }
            
            
        }
        
    }

    static void showTab(Etudiant[] arr,int nb){

        for (int i = 0; i < arr.length; i++) {
            int a=i+1;
            System.out.println("Etudiant "+a+": "+arr[i]+" ");
            
        }
    }
    public static void main(String[] args) {
        Etudiant etd1= new Etudiant("koffi", "jiji", 20);
        Etudiant etd2= new Etudiant("apoutchou", "kelly", 25);
        Etudiant etd3= new Etudiant("komla", "emma", 19);

        Etudiant[] etdArr={etd2,etd1,etd3};
        int lg=etdArr.length;

        System.out.println("Avant tri");
        showTab(etdArr, lg);
        
        ArraytoTree(etdArr, lg);

        System.out.println("Apres tri");
        showTab(etdArr, lg);

        maxAge(etdArr, lg);


    }
    
}