package Exercice1;

class Etudiant {
    String nom,pnom;
    int age;
    
    public Etudiant(String nom,String pnom,int age){
        this.age=age;
        this.nom=nom;
        this.pnom=pnom;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return "Etudiant "+nom+" "+pnom+" Age: "+age;
    }
}
