package Exercice4;

import java.util.Scanner;

public class Recursive {
    static int puissance(int base, int expo){
        int result;
        if (expo==1) {
            result=base;
            return result;
        }
        else if (expo==0) {
            result=1;
            return result;
        }
        else{
            result=base*puissance(base, expo-1);
            return result;
        }
        
        
    }
    public static void main(String[] args) {
        System.out.println("Calcul de puissance");
        Scanner obj=new Scanner(System.in);

        System.out.println("Entrer la base");
        int a=obj.nextInt();

        System.out.println("Entrer l`exposant");
        int b=obj.nextInt();
        
        System.out.println(a+" puissance "+b+" egal "+puissance(a, b));
    }
}
