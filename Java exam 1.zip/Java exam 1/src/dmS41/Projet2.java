package dmS41;

import dms42.Animal;

public class Projet2 {
    public static void main(String[] args) {
        // la classe Animal n'appartient pas au même package que la classe Projet2 donc on va importer la classe en fonction du package dans lequel il se trouve
        // les methodes de la classe ne sont pas visibles dans ce package-ci donc on va changer la visibilité des méthodes de default en public
        // afin qu'elles soient accessibles dans un autre package
        Animal animal=new Animal();
        animal.deplacer();
        //Pour afficher le resultat de ce code il doit etre mis en paramètre au S.o.p
        System.out.println(animal.avoirPatte(2));;
    }
}
