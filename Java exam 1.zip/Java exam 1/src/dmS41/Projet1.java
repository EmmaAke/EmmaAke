package dmS41;
public class Projet1 {
    public static String ds ="Devoir surveille N1";
    public static void main(String[] args) {
        Projet1 projet=new Projet1();
        //la variable ds n'existe pas dans le corps de la méthode mais en dehors et donc pour y accéder la variable doit recevoir le mot-clé static
        projet.composer(ds);
    }
    
    //la variable ds qui est passée en paramètre au S.o.p n'existe pas dans le corps de la méthode donc on va lui affecter la variable passée en paramètre 
    //à la méthode c'est a dire chaine
    //la méthode composer() peut etre ou non declarée sans le mot-clé static mais de préférence on peut l'enlever
    public static void composer(String chaine) {
        System.out.println(chaine);
    }

    //La methode fn retourne un entier or on lui a passé un string en paramètre donc il y a erreur. Pour corriger cela on va changer le String en int
    public int fn (int nombreEntier){
        return nombreEntier;
    }
}