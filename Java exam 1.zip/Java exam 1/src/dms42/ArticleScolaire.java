package dms42;

//la classe ArticleScolaire doit implémenter la méthode abstraite calculTva() de l'interface ProduitAvecTva
public class ArticleScolaire extends ProduitAvecTva{    
    public static final double tauxTVA=18/100;

    private double prixUnitaire;
    private int quantite;
    @Override
    public double calculTva() {
        // TODO Auto-generated method stub
        double tva=prixUnitaire*quantite*tauxTVA;
        return tva;
    }
}
