package dms42;

public class Etudiant extends Humain {
    @Override
    public void manger() {
        // TODO Auto-generated method stub
        System.out.println("Je mange beaucoup");
    }
    public static void main(String[] args) {
        Etudiant etd=new Etudiant();
        etd.manger();
    }
}
