package dms42;

public interface PasDeQueue {
    public final int longueurQueue=0;
    public boolean aUneQueue();
}
