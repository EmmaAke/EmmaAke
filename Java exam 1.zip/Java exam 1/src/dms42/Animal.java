package dms42;

public class Animal{
    public void deplacer(){
        System.out.println("Je me deplace");
    }

    public boolean avoirPatte(int nbre){
        return nbre == 0 ? false : true;
    }
    
}