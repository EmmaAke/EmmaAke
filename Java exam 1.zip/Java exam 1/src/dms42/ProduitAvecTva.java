package dms42;

public abstract class ProduitAvecTva {
    public abstract double calculTva();
    //tva=pu*ate*tauxTVA
}
