package dms42;

public interface ProduitSansTva {
    public double retenu();
    //r=pu*qte*0.10
}
