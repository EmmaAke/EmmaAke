package dms42;

public class Humain {
    //1-  1ère version
    public void manger(){
        System.out.println("Je mange bien");
    }
    //1-  2ème version
    public void manger(String aliment){
        System.out.println("J'ai mange "+aliment);
    }
    //1-  3ème version
    public void manger(int nbre){
        System.out.println("J'ai mange "+nbre+" fruits");
    }

    // 3-La surcharge de méthode est utilisée pour améliorer la lisibilité du programme et est effectuée dans la classe elle même.
    //  La redéfinition de méthode est utilisée pour fournir l'implémentation spécifique de la méthode qui est déjà fournie par sa super classe. 
    
}
