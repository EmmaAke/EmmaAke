package dms42;

public class Personne {
    public boolean avoirCheveux(){
        return true;
    }
}
