package dms42;
//la classe Legume doit implémenter la méthode abstraite retenu() de l'interface ProduitSansTva
public class Legume implements ProduitSansTva{

    private double prixUnitaire;
    private int quantite;

    @Override
    public double retenu() {
        // TODO Auto-generated method stub
        double retenu=prixUnitaire*quantite*0.10;
        return retenu;
    }
    
}
