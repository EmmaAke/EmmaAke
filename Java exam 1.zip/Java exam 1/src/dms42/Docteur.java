package dms42;

public class Docteur extends Personne implements PasDeQueue {
    @Override
    public boolean aUneQueue() {
        // TODO Auto-generated method stub
        return false;
    }

    public static void main(String[] args) {
        Personne p=new Docteur();
        //Le polymorphisme est le fait qu'un objet instancié d'une classe fille peut utiliser le nom de la classe mère comme type de l'objet
        //
        Docteur p1=(Docteur)p;
        System.out.println(p1.aUneQueue());
    }
    
}
